import UIKit

class FavoriteRecipeListController: UITableViewController {

    
    @IBOutlet weak var emptyView: UIView!
    
    @IBOutlet weak var favoriteTableView: UITableView!
    
    
    private let localRepository = RecipeLocalRepository()
    private var localRecipes = [Recipe]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.delegate = self
        tableView.dataSource = self
        
        let nibCell = UINib(nibName: "RecipeListCell", bundle: nil)
        tableView.register(nibCell, forCellReuseIdentifier: RecipeListCell.reuseIdentifier)
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        localRecipes = localRepository.getAll()
        // noResultView.isHidden = localRecipes.isEmpty == false
        // tableView.isHidden = localRecipes.isEmpty
        tableView.reloadData()
    }
}

// MARK: - RecipeListCellDelegate

extension FavoriteRecipeListController: RecipeListCellDelegate {
    
    func favoriteButtonTapped(for recipe: Recipe, at index: Int) {
        print("favoriteButtonTapped dans le controller")
        _ = localRepository.delete(byIdentifier: recipe.id)
        localRecipes.removeAll { $0.id == recipe.id }
        localRecipes = localRepository.getAll()
        // noResultView.isHidden = localRecipes.isEmpty == false
        // tableView.isHidden = localRecipes.isEmpty
        tableView.reloadData()
    }
    
    private func configureEmptyState() {
            if localRecipes.isEmpty {
                // Affichez l'image lorsque la TableView est vide
                favoriteTableView.isHidden = true
                emptyView.isHidden = false
            } else {
                // Masquez l'image lorsque la TableView a des données
                favoriteTableView.isHidden = false
                emptyView.isHidden = true
            }
        }
}

// MARK: - UITableViewDataSource

extension FavoriteRecipeListController {
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return localRecipes.count
    }
    
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(
            withIdentifier: RecipeListCell.reuseIdentifier,
            for: indexPath
        ) as? RecipeListCell
        
        guard let cell else { return UITableViewCell() }
        
        let recipe = localRecipes[indexPath.row]
        
        print("current cell is reloaded")
        cell.configure(with: recipe, isFavorite: true, index: indexPath.row)//, isFavorite: isFavorite)
        cell.delegate = self
        
        return cell
    }
}

// MARK: - UITableViewDelegate

extension FavoriteRecipeListController {
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "RecipeDetailController", bundle: nil) // Remplacez "Main" par le nom de votre storyboard
        guard let recipeDetailController = storyboard.instantiateViewController(withIdentifier: "RecipeDetailController") as? RecipeDetailController else {
            return
        }
        let selectedRecipe = localRecipes[indexPath.row]
        
        // Instancier RecipeInstructionController et lui transmettre la recette sélectionnée
        recipeDetailController.recipe = selectedRecipe
        recipeDetailController.isFavorite = true
        
        // Présenter RecipeInstructionController
        self.navigationController?.pushViewController(recipeDetailController, animated: true)
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        116
    }
}
