import UIKit

public class TabBarController: UITabBarController {
    
    override public func viewDidLoad() {
        super.viewDidLoad()
        setUpViewControllers()
    }
    
    func setUpViewControllers() {
        let firstVC = UIStoryboard(name: "SearchController", bundle: nil).instantiateInitialViewController() as? SearchController
        let secondVC = UIStoryboard(name: "FavoriteRecipeListController", bundle: nil).instantiateInitialViewController() as? FavoriteRecipeListController
        
        guard let firstVC, let secondVC else { return }
        
        firstVC.tabBarItem = UITabBarItem(tabBarSystemItem: .search, tag: 0)
        secondVC.tabBarItem = UITabBarItem(tabBarSystemItem: .favorites, tag: 0)
        
        viewControllers = [firstVC, secondVC]
    }
}
