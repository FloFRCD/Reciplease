import UIKit

class SearchController: UIViewController {
    
    // MARK: - Views
    
    @IBOutlet weak var ingredientTextField: UITextField!
    @IBOutlet weak var ingredientTableView: UITableView!
    @IBOutlet weak var searchButton: UIButton!
    @IBOutlet weak var clearButton: UIButton!
    
    // MARK: - Properties
    
    var ingredients: [String] = []
    private var nextLinkRecipe: String?
    
    // MARK: - Init
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.isNavigationBarHidden = true
        
        ingredientTableView.dataSource = self
        
        let nib = UINib(nibName: "IngredientCell", bundle: nil)
        ingredientTableView.register(nib, forCellReuseIdentifier: IngredientCell.identifier)
        
        updateButtonStateIfNeeded()
    }
    
    @IBAction func addIngredient(_ sender: Any) {
        if let ingredient = ingredientTextField.text, !ingredient.isEmpty {
            ingredients.append(ingredient)
            ingredientTextField.text = ""
            ingredientTableView.reloadData()
        }
        
        updateButtonStateIfNeeded()
    }
    
    @IBAction func clearIngredient(_ sender: Any) {
        ingredients = []
        updateButtonStateIfNeeded()
        
        ingredientTableView.reloadData()
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        guard let navigationController = segue.destination as? UINavigationController,
              let controller = navigationController.children.first as? RecipeListController else {
            return
        }
        controller.ingredients = ingredients
    }
}

// MARK: - Convenience Methods

extension SearchController {
    
    private func updateButtonStateIfNeeded() {
        let shouldBeEnabled = ingredients.isEmpty == false
        searchButton.isEnabled = shouldBeEnabled
        
        let color: UIColor = shouldBeEnabled ? .lightGray : .lightGray.withAlphaComponent(0.5)
        searchButton.tintColor = color
        searchButton.setTitleColor(color, for: .normal)
        searchButton.layer.borderColor = color.cgColor
    }
}

// MARK: - UITableViewDataSource

extension SearchController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        ingredients.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: IngredientCell.identifier) as? IngredientCell else {
            return UITableViewCell()
        }
        
        let ingredient = ingredients[indexPath.row]
        cell.configure(title: ingredient)
        
        return cell
    }
    
    private func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
        return .delete
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            tableView.beginUpdates()
            ingredients.remove(at: indexPath.row)
            tableView.deleteRows(at: [indexPath], with: .fade)
            tableView.endUpdates()
        }
    }
}
