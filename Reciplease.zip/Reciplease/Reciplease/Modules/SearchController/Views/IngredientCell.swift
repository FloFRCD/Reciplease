import UIKit

class IngredientCell: UITableViewCell {
    
    static let identifier = "ingredient-cell"
    
    @IBOutlet weak var titleLabel: UILabel!
    
    // TOCHECK: - The way tableView cells are init
    // init(required:
    
    func configure(title: String) {
        titleLabel.text = "- " + title
    }
    
    func clearList() {
        titleLabel.text = ""
    }
}
