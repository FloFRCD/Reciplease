import Foundation
import UIKit
import SDWebImage
import CoreData

protocol RecipeListCellDelegate: AnyObject {
    func favoriteButtonTapped(for recipe: Recipe, at index: Int)
}

class RecipeListCell: UITableViewCell {
    
    @IBOutlet weak private var recipeImage: UIImageView!
    @IBOutlet weak private var recipeNameLabel: UILabel!
    @IBOutlet weak private var timeLabel: UILabel!
    
    @IBOutlet weak private var favoriteImageView: UIImageView!
    @IBOutlet weak private var favoriteButton: UIButton!
    
    private var recipe: Recipe?
    private var index: Int?
    
    internal weak var delegate: RecipeListCellDelegate?
    internal static let reuseIdentifier = "recipe-list-cell"
    
    @IBAction func favoriteButtonTapped(_ sender: Any) {
        guard let recipe, let index else { return }
        delegate?.favoriteButtonTapped(for: recipe, at: index)
        
        // Désactiver temporairement le bouton pour éviter les clics répétés
        favoriteButton.isEnabled = false
        
        // Réactivez le bouton après un délai
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.5) {
            self.favoriteButton.isEnabled = true
        }
    }
}

// MARK: - Public Methods

extension RecipeListCell {
    
    func configure(with recipe: Recipe, isFavorite: Bool, index: Int) {
        print("cell is configured")
        print("id: \(recipe.id) - isFavorite: \(isFavorite)\n\n")
        
        self.recipe = recipe
        self.index = index
        
        // recipeNameLabel.adjustsFontSizeToFitWidth = true
        recipeNameLabel.text = recipe.title
        
        let preparationTimeDouble = recipe.totalTime
        let preparationTimeString = String(preparationTimeDouble)
        timeLabel.text = preparationTimeString
        
        let imageName = isFavorite ? "hand.thumbsup.fill" : "hand.thumbsup"
        favoriteImageView.image = UIImage(systemName: imageName)
        
        
        if let imageURLString = recipe.imageURL?.absoluteString, let imageURL = URL(string: imageURLString) {
            recipeImage.sd_setImage(with: imageURL, completed: nil)
        }
        
    }
}
