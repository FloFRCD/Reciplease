import UIKit
import SDWebImage

class RecipeListController: UIViewController {
    
    // MARK: - Views
    
    @IBOutlet weak var recipeListTableView: UITableView!
    
    // MARK: - Proeprties
    
    internal var ingredients = [String]()
    
    private var localRecipes = [Recipe]()
    private var recipes = [Recipe]()
    
    private let localRepository = RecipeLocalRepository()
    private let remoteRepository = RecipeRemoteRepository()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        localRecipes = localRepository.getAll()
        
        recipeListTableView.delegate = self
        recipeListTableView.dataSource = self
        
        let nibCell = UINib(nibName: "RecipeListCell", bundle: nil)
        recipeListTableView.register(nibCell, forCellReuseIdentifier: RecipeListCell.reuseIdentifier)
        
        loadRecipes()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        self.title = "Liste des résultats"
        
        let cancelBarButton = UIBarButtonItem(barButtonSystemItem: .cancel, target: self, action: #selector(dismissView))
        self.navigationItem.leftBarButtonItem = cancelBarButton
    }
    
    @objc private func dismissView() {
        self.navigationController?.dismiss(animated: true)
    }
}

// MARK: - RecipeListCellDelegate

extension RecipeListController: RecipeListCellDelegate {
    
    func favoriteButtonTapped(for recipe: Recipe, at index: Int) {
        print("favoriteButtonTapped dans le controller")
        let recipeAlreadyExists = localRecipes.first(where: { $0.id == recipe.id }) != nil
        
        if recipeAlreadyExists {
            // La recette existe localement, supprimez-la
            
            _ = localRepository.delete(byIdentifier: recipe.id)
            localRecipes.removeAll { $0.id == recipe.id }
        } else {
            // La recette n'existe pas localement, ajoutez-la
            localRepository.create(record: recipe)
            localRecipes.append(recipe)
        }
        
        localRecipes = localRepository.getAll()
        
        let indexPath = IndexPath(item: index, section: 0)
        recipeListTableView.reloadRows(at: [indexPath], with: .automatic)
    }
}

// MARK: - UITableViewDataSource

extension RecipeListController : UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return recipes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(
            withIdentifier: RecipeListCell.reuseIdentifier,
            for: indexPath
        ) as? RecipeListCell
        
        guard let cell else { return UITableViewCell() }
        
        let recipe = recipes[indexPath.row]
        
        print("current cell is reloaded")
        let isFavorite = localRecipes.first(where: { $0.id == recipe.id }) != nil
        cell.configure(with: recipe, isFavorite: isFavorite, index: indexPath.row)//, isFavorite: isFavorite)
        cell.delegate = self
        
        return cell
    }
}

// MARK: - UITableViewDelegate

extension RecipeListController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard = UIStoryboard(name: "RecipeDetailController", bundle: nil) // Remplacez "Main" par le nom de votre storyboard
        guard let recipeDetailController = storyboard.instantiateViewController(withIdentifier: "RecipeDetailController") as? RecipeDetailController else {
            return
        }
        let selectedRecipe = recipes[indexPath.row]
        
        // Instancier RecipeInstructionController et lui transmettre la recette sélectionnée
        recipeDetailController.recipe = selectedRecipe
        
        // Présenter RecipeInstructionController
        self.navigationController?.pushViewController(recipeDetailController, animated: true)
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        let isAlmostAtTheEndOfTheTableView = indexPath.row == recipes.count - 5
        
        guard isAlmostAtTheEndOfTheTableView else { return }
        // Lancer une nouvelle requête
        print("Lancer une nouvelle requête")
        loadNextRecipesIfNeeded()
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        116
    }
}

// MARK: - Network

extension RecipeListController {
    
    private func loadRecipes() {
        remoteRepository.getRecipes(ingredients: ingredients, completion: { [weak self] result in
            guard let self else { return }
            
            switch result {
            case .success(let recipes):
                self.reloadData(with: recipes)
            case .failure(let error):
                self.presentAlert(with: error)
            }
        })
    }
    
    private func loadNextRecipesIfNeeded() {
        // Faire l'appel réseau pour recevoir de nouvelles recettes
        let newRecipes = [Recipe]()
        self.recipes.append(contentsOf: newRecipes)
    }
    
    private func reloadData(with recipes: [Recipe]) {
        self.recipes = recipes
        DispatchQueue.main.async {
            self.recipeListTableView.reloadData()
        }
    }
    
    private func presentAlert(with error: Error) {
        
    }
}
