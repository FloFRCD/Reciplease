import UIKit

class RecipeInstructionController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

    }

}
