import UIKit

class RecipeDetailController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var recipeImageView: UIImageView!
    @IBOutlet weak var recipeNameLabel: UILabel!
    @IBOutlet weak var recipeIngredientsTableView: UITableView!
    @IBOutlet weak var recipeTimeLabel: UILabel!
    @IBOutlet weak var recipeFavoriteImageView: UIImageView!
    
    @IBOutlet weak var ingredientsTableView: UITableView!
    
    
    var currentImage : UIImage?
    var recipe: Recipe?
    var isFavorite: Bool = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        recipeNameLabel.text = recipe?.title
        let preparationTimeDouble = recipe?.totalTime ?? 0.0
        let preparationTimeString = String(preparationTimeDouble)
        recipeTimeLabel.text = preparationTimeString
        
        let imageName = isFavorite ? "hand.thumbsup.fill" : "hand.thumbsup"
        recipeFavoriteImageView.image = UIImage(systemName: imageName)
        
        
        if let imageURLString = recipe?.imageURL?.absoluteString, let imageURL = URL(string: imageURLString) {
            recipeImageView.sd_setImage(with: imageURL, completed: nil)
        }
        
        recipeIngredientsTableView.dataSource = self
        recipeIngredientsTableView.delegate = self
        
        let nib = UINib(nibName: "DetailIngredientCell", bundle: nil)
        ingredientsTableView.register(nib, forCellReuseIdentifier: IngredientCell.identifier)
    }
    
    @IBAction func recipeInstructionButtonIsTapped(_ sender: Any) {
    }
    
}


extension RecipeDetailController {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return recipe?.ingredients.count ?? 0
        }

        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "DetailIngredientCell", for: indexPath)
            if let ingredient = recipe?.ingredients[indexPath.row] {
                cell.textLabel?.text = "- " + ingredient.title // Ajoutez le préfixe "-"
            }
            return cell
        }
}
