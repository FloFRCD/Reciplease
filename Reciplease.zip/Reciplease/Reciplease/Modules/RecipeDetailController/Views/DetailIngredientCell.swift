//
//  DetailListCell.swift
//  Reciplease
//
//  Created by Florian Fourcade on 24/09/2023.
//

import Foundation
import UIKit

class DetailIngredientCell: UITableViewCell {
    
    @IBOutlet weak var titleLabel: UILabel!
    
    
    static let identifier = "detail-ingredient-cell"
    
    
    // TOCHECK: - The way tableView cells are init
    // init(required:
    
    func configure(title: String) {
        titleLabel.text = "- " + title
    }
    
}
    
