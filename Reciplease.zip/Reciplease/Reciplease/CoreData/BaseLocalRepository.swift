//
//  BaseLocalRepository.swift
//  Reciplease
//
//  Created by Florian Fourcade on 20/08/2023.
//

import Foundation

protocol BaseRepository {

    associatedtype T

    func create(record: T)
    func getAll() -> [T]
    func get(byIdentifier id: String) -> T?
    func delete(byIdentifier id: String) -> Bool
}
