//
//  CDIngredient+CoreDataClass.swift
//  Reciplease
//
//  Created by Florian Fourcade on 14/08/2023.
//
//

import Foundation
import CoreData


public class CDIngredient: NSManagedObject {

}
