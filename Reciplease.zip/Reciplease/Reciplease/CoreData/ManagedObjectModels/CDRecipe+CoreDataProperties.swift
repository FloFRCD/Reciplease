//
//  CDRecipe+CoreDataProperties.swift
//  Reciplease
//
//  Created by Florian Fourcade on 14/08/2023.
//
//

import Foundation
import CoreData


extension CDRecipe {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDRecipe> {
        return NSFetchRequest<CDRecipe>(entityName: "CDRecipe")
    }

    @NSManaged public var title: String
    @NSManaged public var yield: Double
    @NSManaged public var id: String
    @NSManaged public var ingredients: Set<CDIngredient>
    @NSManaged public var totalTime: Double
    @NSManaged public var imageURL: URL
}

// MARK: Generated accessors for ingredients
extension CDRecipe {

    @objc(addIngredientsObject:)
    @NSManaged public func addToIngredients(_ value: CDIngredient)

    @objc(removeIngredientsObject:)
    @NSManaged public func removeFromIngredients(_ value: CDIngredient)

    @objc(addIngredients:)
    @NSManaged public func addToIngredients(_ values: Set<CDIngredient>)

    @objc(removeIngredients:)
    @NSManaged public func removeFromIngredients(_ values: Set<CDIngredient>)

}

extension CDRecipe : Identifiable {

}
