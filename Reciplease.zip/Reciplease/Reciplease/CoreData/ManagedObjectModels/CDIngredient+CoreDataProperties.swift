//
//  CDIngredient+CoreDataProperties.swift
//  Reciplease
//
//  Created by Florian Fourcade on 14/08/2023.
//
//

import Foundation
import CoreData


extension CDIngredient {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<CDIngredient> {
        return NSFetchRequest<CDIngredient>(entityName: "CDIngredient")
    }

    @NSManaged public var title: String
    @NSManaged public var quantity: String
    @NSManaged public var recipe: CDIngredient?
}

extension CDIngredient : Identifiable {

}
