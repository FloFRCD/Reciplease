//
//  CDIngredientExtensions.swift
//  Reciplease
//
//  Created by Florian Fourcade on 26/08/2023.
//

import Foundation

extension CDIngredient {
    
    func convertToIngredient() -> Ingredient {
        let titleValue = self.title
        let quantityValue = self.quantity
        
        return Ingredient(title: titleValue, quantity: quantityValue)
    }
}
