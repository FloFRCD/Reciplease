//
//  CDRecipeExtensions.swift
//  Reciplease
//
//  Created by Florian Fourcade on 26/08/2023.
//
import Foundation

extension CDRecipe {
    
    func convertToRecipe() -> Recipe {
        return Recipe(
            id: self.id,
            title: self.title,
            imageURL: self.imageURL,
            yield: self.yield,
            ingredients: self.convertToIngredients(),
            totalTime: self.totalTime
        )
    }
    
    private func convertToIngredients() -> [Ingredient] {
        guard !ingredients.isEmpty else { return [] }
        return ingredients.compactMap { $0.convertToIngredient() }
    }
    
}
