//
//  PersistantStorage.swift
//  Reciplease
//
//  Created by Florian Fourcade on 14/08/2023.
//

// Copier coller le fichier BaseRepository (l'appeler BaseLocalRepository) V
// Copier coller le fichier RecipeLocalRepository (Pour le fichier s'occupant de l'appel API, l'appeler RecipeRemoteRepository), au moins t'auras un Local et un Remote. V
// Si tu l'utilises dans le ViewController:
// let localRepository = RecipeLocalRepository()
// let remoteRepository = RecipeRemoteRepository()
// localRepository.getAll()
// remoteRepository.getRecipes {}

// Tester le RecipeLocalRepository V
// T'inspirer du projet Save (ViewController)

import Foundation
import CoreData

final class PersistentStorage {

    private init() {}
    static let shared = PersistentStorage()
    
    // MARK: - Properties
    
    lazy var persistentContainer: NSPersistentContainer = {

        let container = NSPersistentContainer(name: "RecipleaseDataModel")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {

                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()

    lazy var context = persistentContainer.viewContext
}

// MARK: - Convenience Methods

extension PersistentStorage {
    
    func saveContext() {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }

    func fetchManagedObject<T: NSManagedObject>(managedObject: T.Type) -> [T]? {
        do {
            guard let result = try PersistentStorage.shared.context.fetch(managedObject.fetchRequest()) as? [T] else {
                return nil
            }

            return result
        } catch let error {
            debugPrint(error)
        }

        return nil
    }
}
