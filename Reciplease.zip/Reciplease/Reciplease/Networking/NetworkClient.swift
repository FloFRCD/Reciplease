//
//  NetworkClient.swift
//  Reciplease
//
//  Created by Florian Fourcade on 24/05/2023.
//

import Foundation

class NetworkClient {
    
    
}
