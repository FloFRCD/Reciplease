//
//  todo.swift
//  Reciplease
//
//  Created by Florian Fourcade on 25/10/2022.
//

//import Foundation
//- barre de navigationvsur premier ecran de recherche / ?
//- griser le bouton / OK
//- appel API
//- retrouver le JSON / OK
//- afficher la liste des recette
//- regarder coredata / OK
