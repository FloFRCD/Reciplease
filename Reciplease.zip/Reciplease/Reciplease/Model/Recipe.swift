import Foundation
import UIKit

// Voir Postman pour faire une requête avec les paramètres field
// Voir l'API edamame pour savoir si 'instructions' fait parti d'un plan payant
// Vérifier pourquoi la propriété 'instructions' n'existe pas

struct Recipe: Decodable, Equatable {
    
    let id: String
    let title: String
    let imageURL: URL?
    let yield: Double
    let ingredients: [Ingredient]
    let totalTime: Double
    
    enum CodingKeys: String, CodingKey {
        case id = "uri"
        case title = "label"
        case imageURLString = "image"
        case yield
        case ingredients
        case totalTime
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        let uri = try container.decode(String.self, forKey: .id)
        self.id = uri.replacingOccurrences(of: "http://www.edamam.com/ontologies/edamam.owl#recipe_", with: "")
        self.title = try container.decode(String.self, forKey: .title)
        
        let imageURLString: String = try container.decode(String.self, forKey: .imageURLString)
        self.imageURL = URL(string: imageURLString)
        
        self.yield = try container.decode(Double.self, forKey: .yield)
        self.ingredients = try container.decode([Ingredient].self, forKey: .ingredients)
        self.totalTime = try container.decode(Double.self, forKey: .totalTime)
    }
    
    init(
        id: String,
        title: String,
        imageURL: URL?,
        yield: Double,
        ingredients: [Ingredient],
        totalTime: Double
    ) {
        self.id = id
        self.title = title
        self.imageURL = imageURL
        self.yield = yield
        self.ingredients = ingredients
        self.totalTime = totalTime
    }
    
    static func == (lhs: Recipe, rhs: Recipe) -> Bool {
        return lhs.id == rhs.id &&
        lhs.title == rhs.title &&
        lhs.imageURL == rhs.imageURL &&
        lhs.yield == rhs.yield &&
        lhs.ingredients == rhs.ingredients &&
        lhs.totalTime == rhs.totalTime
    }
}
