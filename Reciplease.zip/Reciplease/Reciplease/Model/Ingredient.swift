import Foundation

struct Ingredient: Decodable, Equatable {

    var title: String
    var quantity: String
    
    enum CodingKeys: String, CodingKey {
        case title = "text"
        case quantity
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        
        self.title = try container.decode(String.self, forKey: .title)
        
        let quantityDouble = try container.decode(Double.self, forKey: .quantity)
        self.quantity = String(quantityDouble)
    }
    
    init(
        title: String,
        quantity: String
    ) {
        self.title = title
        self.quantity = quantity
    }
}
