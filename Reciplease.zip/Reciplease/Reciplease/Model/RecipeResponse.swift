//
//  RawRecipeResponse.swift
//  Reciplease
//
//  Created by Florian Fourcade on 03/09/2023.
//

import Foundation

struct RecipeResponse: Decodable {
    
    var from: Int
    var to: Int
    var count: Int
    var hits: [RecipeHit]
    
    enum CodingKeys: String, CodingKey {
        case from
        case to
        case count
        // case links = "_links"
        case hits
    }
}

struct RecipeHit: Decodable {
    var recipe: Recipe
    
    private enum CodingKeys: String, CodingKey {
        case recipe
    }
}
