//
//  MockAlamofireImageServiceProtocol.swift
//  RecipleaseTests
//
//  Created by Florian Fourcade on 22/08/2022.
//

import Alamofire
import Foundation

@testable import Reciplease

class MockAlamofireImageServiceProtocol: ImageRecipeServiceAlamofireProtocol {
    
    var data: Data?
    
    func request(_ urlImage: String, completion: @escaping (Data?) -> Void) {
        completion(data)
    }
}
