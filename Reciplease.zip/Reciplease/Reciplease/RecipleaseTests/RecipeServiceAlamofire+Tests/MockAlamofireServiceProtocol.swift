//
//  MockAlamofireServiceProtocol.swift
//  RecipleaseTests
//
//  Created by Florian Fourcade on 22/08/2022.
//


import Foundation

@testable import Reciplease
import Alamofire

class MockAlamofireServiceProtocol: AlamofireServiceProtocol {
    
    var data : Data?
    
    func request(_ convertible: URLConvertible, method: HTTPMethod, parameters: Parameters?, encoding: ParameterEncoding, headers: HTTPHeaders?, interceptor: RequestInterceptor?, completion: @escaping (Data?) -> Void) {
        completion(data)
    }
}
