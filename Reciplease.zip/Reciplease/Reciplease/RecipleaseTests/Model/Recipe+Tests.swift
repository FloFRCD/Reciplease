//
//  Recipe+Tests.swift
//  RecipleaseTests
//
//  Created by Florian Fourcade on 12/07/2023.
//

import Foundation
import XCTest

@testable import Reciplease

class Recipe_Tests: XCTestCase {
    
    func test_init() {
        
        // arrange - Récupérer le fichier en Data (recipes)
        
        // act - Créer l'object à partir de la data
//        let recipeSearchResponse = try decoder.decode(RecipeSearchResponse.self, from: data)
//        let recipes = recipeSearchResponse.hits.compactMap { $0.recipe }
        // let recipe = recipes.first!
        
        // assert
        //"https://fblfjpodf#recipe_2fb391cceeec3d82920a2035f1849d72".split(separator: "#recipe_").last
        
        //XCTAssertEqual(recipe.id, "2fb391cceeec3d82920a2035f1849d72")
    }
}
