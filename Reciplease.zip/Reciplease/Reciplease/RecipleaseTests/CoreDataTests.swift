//
//  CoreDataTests.swift
//  RecipleaseTests
//
//  Created by Florian Fourcade on 27/06/2023.
//

import XCTest

@testable import Reciplease

class CoreDataTests: TestCase {
    
    var recipe: Recipe!
    
    override func setUp() {
        super.setUp()
        recipe = Recipe(id: "2fb391cceeec3d82920a2035f1849d72",
                        title: "Recette fictive",
                        imageURL: URL(string: "https://example.com/image.jpg")!,
                        yield: 2,
                        ingredients: [],
                        totalTime: 10)
    }
    
    override func tearDown() {
        recipe = nil
        super.tearDown()
    }
    
    func testRecipeIDExtraction() {
        // Créez un exemple d'URI de recette
        let uri = "http://www.edamam.com/ontologies/edamam.owl#recipe_2fb391cceeec3d82920a2035f1849d72"
        
        // Appelez la méthode pour extraire l'ID de l'URI
        let id = uri.replacingOccurrences(of: "http://www.edamam.com/ontologies/edamam.owl#recipe_", with: "")
        
        // Vérifiez si l'ID correspond à la valeur attendue
        XCTAssertEqual(id, "2fb391cceeec3d82920a2035f1849d72", "Recipe ID extraction failed")
    }
    
    func testRecipeIDExtraction2() {
        let uri = "http://www.edamam.com/ontologies/edamam.owl#recipe_2fb391cceeec3d82920a2035f1849d72"
        let decoder = JSONDecoder()
        let data = """
            {
                "uri": "\(uri)",
                "label": "Example Recipe",
                "image": "http://example.com/image.jpg",
                "yield": 4,
                "ingredients": [],
                "totalTime": 30
            }
            """.data(using: .utf8)!
        
        do {
            let recipe = try decoder.decode(Recipe.self, from: data)
            
            XCTAssertEqual(recipe.id, "2fb391cceeec3d82920a2035f1849d72", "Recipe ID extraction failed")
        } catch {
            XCTFail("Failed to decode recipe: \(error)")
        }
    }
    
    
    func testSaveRecipe() {
        let json = getJSON(fromFile: "recipes")
        
        do {
            let data = Data(json.utf8)
            _ = try JSONDecoder().decode(RecipeSearchResponse.self, from: data)

            // ... Votre code de test ici en utilisant les recettes chargées à partir du JSON ...
            
        } catch {
            XCTFail("Erreur lors du décodage du JSON : \(error)")
        }
    }

    func testSaveRecipe2() {
        // Le contenu JSON directement dans une chaîne
        let jsonString = getJSON(fromFile: "recipes")

        // Convertir la chaîne JSON en données
        guard let jsonData = jsonString.data(using: .utf8) else {
            XCTFail("Erreur lors de la conversion en données JSON.")
            return
        }

        do {
            // Décoder directement à partir des données JSON
            let searchResponse = try JSONDecoder().decode(RecipeSearchResponse.self, from: jsonData)
            // Check searchResponse values
            
            let recipes = searchResponse.hits.compactMap { $0.recipe }
            
            for recipe in recipes {
                let expectation = XCTestExpectation(description: "Sauvegarde de la recette \(recipe.title)")
                
                RecipeDataManager.shared.saveRecipe(recipe: recipe) { success in
                    XCTAssertTrue(success, "La sauvegarde de la recette \(recipe.title) a échoué.")
                    expectation.fulfill()
                }
                
                wait(for: [expectation], timeout: 5.0)
            }
            
            // Une fois les recettes sauvegardées, vous pouvez utiliser la fonction getFavoriteRecipes()
            // pour vérifier si les recettes ont été correctement sauvegardées dans CoreData.
            let favoriteRecipes = RecipeDataManager.shared.getFavoriteRecipes()
            
            // Comparez les recettes sauvegardées avec les recettes d'origine
            XCTAssertEqual(favoriteRecipes.count, recipes.count, "Le nombre de recettes sauvegardées ne correspond pas au nombre de recettes d'origine.")
            
            for (index, recipe) in recipes.enumerated() {
                let savedRecipe = favoriteRecipes[index]
                
                XCTAssertEqual(savedRecipe.title, recipe.title, "Le titre de la recette sauvegardée ne correspond pas à celui de la recette d'origine.")
                XCTAssertEqual(savedRecipe.imageURL, recipe.imageURL, "L'URL de l'image de la recette sauvegardée ne correspond pas à celle de la recette d'origine.")
                // Comparez les autres propriétés de la recette ici...
                
                // Vérifiez si les ingrédients sont correctement sauvegardés (vous devrez peut-être implémenter cette vérification en fonction de votre logique de sauvegarde d'ingrédients dans CoreData)
                
            }
            
        } catch {
            XCTFail("Erreur lors du décodage du JSON : \(error)")
        }
    }
    
    func testSaveRecipe3() {
            // Créez une recette fictive pour tester la sauvegarde
            let recipe = Recipe(
                id: "votre_id_de_test",
                title: "Recette de test",
                imageURL: URL(string: "https://example.com/image.jpg"),
                yield: 2.0,
                ingredients: [], // Remplacez ceci par des ingrédients de test si nécessaire
                totalTime: 30.0
            )
            
            // Créez une expectation pour vérifier si la sauvegarde a été effectuée avec succès
            let saveExpectation = expectation(description: "La sauvegarde de la recette a réussi.")
            
            // Appelez la fonction de sauvegarde
            RecipeDataManager.shared.saveRecipe(recipe: recipe) { success in
                XCTAssertTrue(success, "La recette n'a pas été sauvegardée avec succès.")
                saveExpectation.fulfill()
            }
            
            // Attendre la réalisation de l'expectation pendant un délai raisonnable (par exemple, 5 secondes).
            waitForExpectations(timeout: 5.0, handler: nil)
        }

}
    
//    func testSaveFavoriteRecipe() {
//        // Créer une recette fictive
//        saveRecipe(recipe: recipe)
//
//        // Vérifier que la recette est sauvegardée
//        let savedRecipes = RecipeDataManager.shared.getFavoriteRecipes()
//        XCTAssertTrue(savedRecipes.contains(recipe), "La recette favorite n'a pas été sauvegardée avec succès.")
//    }
//}
//
//private func saveRecipe(recipe: Recipe) {
//        RecipeDataManager.shared.saveRecipe(recipe: recipe) { success in
//            XCTAssertTrue(success, "La sauvegarde de la recette a échoué")
//        }
//    }
//

//extension CoreDataTests {
//
//    private func saveRecipe(recipe: Recipe) {
////        let recipe = Recipe(title: "Recette fictive",
////                            imageURL: "https://example.com/image.jpg")
////                            yield: 2,
////                            ingredients: [],
////                            totalTime: 10,
////                            isFavorite: true)
//
//
//        // Appeler la méthode de sauvegarde
//        RecipeDataManager.shared.saveRecipe(recipe: recipe) { success in
//            XCTAssertTrue(success, "La sauvegarde de la recette a échoué")
//        }
//    }
//}
