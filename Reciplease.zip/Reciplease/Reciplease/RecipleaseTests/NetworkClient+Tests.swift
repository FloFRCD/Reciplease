//
//  NetworkClient+Tests.swift
//  RecipleaseTests
//
//  Created by Florian Fourcade on 24/05/2023.
//

import Foundation
import XCTest

@testable import Reciplease

class NetworkClient_Tests: XCTestCase {
    
    var sut: NetworkClient!
    //2
    var mockSession: MockURLSession!
    //3
    
    override func setUp() {
        sut = nil
        mockSession = nil
        super.setUp()
    }
    
    override func tearDown() {
        sut = nil
        mockSession = nil
        super.tearDown()
    }
    
    func testNetworkClient_successResult() {
        mockSession = createMockSession(
            jsonFile: "recipes",
            statusCode: 200
        )
        sut = NetworkClient(withSession: mockSession)
        
        sut.getRecipes(url: URL(string: "TestUrl")!) { result in
            switch result {
            case .success(let recipes):
                XCTAssertNotNil(recipes)
                XCTAssertEqual(recipes.count, 1)
                let firstRecipe = recipes.first!
                XCTAssertEqual(firstRecipe.title, "Lemon Confit")
            case .failure(_):
                XCTFail("Should not fail")
            }
        }
    }
    //2
    func testNetworkClient_404Result() {
        mockSession = createMockSession(jsonFile: "Search", statusCode: 404)
        sut = NetworkClient(withSession: mockSession)
        
        let expectation = XCTestExpectation(description: "Completion called")
        
        let testURL = URL(string: "TestUrl")!
        
        sut.getRecipes(url: testURL) { result in
            switch result {
            case .success(_):
                XCTFail("Should not succeed")
            case .failure(let error):
                XCTAssertEqual(error as! RecipeServiceError, RecipeServiceError.urlError)
            }
            
            expectation.fulfill()
        }
        
        wait(for: [expectation], timeout: 5.0)
    }
    //3
    func testNetworkClient_NoData() {
        mockSession = createMockSession(statusCode: 500)
        sut = NetworkClient(withSession: mockSession)
        
        let expectation = XCTestExpectation(description: "Completion called")
        
        let testURL = URL(string: "TestUrl")!
        
        sut.getRecipes(url: testURL) { result in
            switch result {
            case .success(_):
                XCTFail("Should not succeed")
            case .failure(let error):
                XCTAssertEqual(error as! RecipeServiceError, RecipeServiceError.statusCode(500))
            }
            
            expectation.fulfill()
        }
        
        wait(for: [expectation], timeout: 5.0)
    }

    //4
    func testNetworkClient_AnotherStatusCode() {
        mockSession = createMockSession(jsonFile: "Search", statusCode: 401)
        sut = NetworkClient(withSession: mockSession)
        
        let expectation = XCTestExpectation(description: "Completion called")
        
        let testURL = URL(string: "TestUrl")!
        
        sut.getRecipes(url: testURL) { result in
            switch result {
            case .success(_):
                XCTFail("Should not succeed")
            case .failure(let error):
                XCTAssertEqual(error as! RecipeServiceError, RecipeServiceError.statusCode(401))
            }
            
            expectation.fulfill()
        }
        
        wait(for: [expectation], timeout: 5.0)
    }

    
    
    func testGetRecipes_Success() {
        guard let jsonData = loadJsonData(file: "recipes") else {
            XCTFail("Failed to load JSON data from file")
            return
        }
        
        let mockURL = URL(string: "https://example.com")!
        let mockURLResponse = HTTPURLResponse(url: mockURL, statusCode: 200, httpVersion: nil, headerFields: nil)!
        let mockSession = MockURLSession(completionHandler: (data: jsonData, response: mockURLResponse, error: nil))
        let client = NetworkClient(withSession: mockSession)
        
        let expectation = XCTestExpectation(description: "Completion called")
        
        //        let ingredients = ["lemon"] // Liste d'ingrédients
        
        //        client.getRecipes(ingredients: ingredients) { result in
        
        let testURL = URL(string: "https://example.com/test")!
        
        client.getRecipes(url: testURL) { result in
            switch result {
            case .success(let recipes):
                XCTAssertEqual(recipes.count, 1)
                XCTAssertEqual(recipes[0].title, "Lemon Confit") // Vérification si le label est correct
            case .failure(let error):
                XCTFail("Unexpected failure: \(error)")
            }
            
            expectation.fulfill()
        }
        wait(for: [expectation], timeout: 5.0)
    }
    
//    func testGetRecipes_OtherStatusCode() {
//        // Créez un client de réseau avec une session mock
//        let mockSession = MockURLSession(completionHandler: (data: nil, response: HTTPURLResponse(url: URL(string: "https://example.com")!, statusCode: 500, httpVersion: nil, headerFields: nil), error: nil))
//        let client = NetworkClient(withSession: mockSession)
//
//        let expectation = XCTestExpectation(description: "Completion called")
//
//        // Appelez la méthode getRecipes avec une URL valide
//        let testURL = URL(string: "https://example.com")!
//        client.getRecipes(url: testURL) { [self] (result: Result<[Recipe], Error>) -> Void in
//            switch result {
//            case .success(_):
//                XCTFail("Expected failure for other status code")
//            case .failure(let error):
//                guard let statusCodeError = error as? RecipeServiceError, case .statusCode(_) = statusCodeError else {
//                    XCTFail("Unexpected error type or structure")
//                    return
//                }
//
//                expectation.fulfill()
//            }
//
//            wait(for: [self.expectation], timeout: 5.0)
//        }
        
        
        // SELECTION MULTIPLE: CTRL + SHIFT
    }

// MARK: - Convenience Methods

extension NetworkClient_Tests {
    
    private func createMockSession(
        jsonFile: String? = nil,
        statusCode: Int,
        error: Error? = nil
    ) -> MockURLSession? {
        
        var data: Data?
        if let jsonFile {
            data = loadJsonData(file: jsonFile)
        }
        
        let response = HTTPURLResponse(url: URL(string: "TestUrl")!, statusCode: statusCode, httpVersion: nil, headerFields: nil)
        
        return MockURLSession(completionHandler: (data, response, error))
    }
    
    private func loadJsonData(file: String) -> Data? {
        //1
        if let jsonFilePath = Bundle(for: type(of:  self)).path(forResource: file, ofType: "json") {
            let jsonFileURL = URL(fileURLWithPath: jsonFilePath)
            
            if let jsonData = try? Data(contentsOf: jsonFileURL) {
                return jsonData
            }
        }
        
        return nil
    }
    
    
    
    
    
}
