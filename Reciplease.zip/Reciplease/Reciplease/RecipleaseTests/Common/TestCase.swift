//
//  TestCase.swift
//  RecipleaseTests
//
//  Created by Florian Fourcade on 29/07/2023.
//

import Foundation
import XCTest

class TestCase: XCTestCase {
    
    func getJSON(fromFile file: String) -> String {
        //let data = getData(fromFile: file)
        let dict = getJSONDict(fromFile: file)
        let json = try! JSONSerialization.data(withJSONObject: dict)
        return String(data: json, encoding: .utf8)!
    }
    
    func getJSONDict(fromFile file: String) -> [String: Any] {
        let data = getData(fromFile: file)
        return try! JSONSerialization.jsonObject(with: data, options: []) as! [String: Any]
    }
    
    private func getData(fromFile file: String) -> Data {
        let bundle = Bundle(for: type(of: self))
        let url = bundle.url(forResource: file, withExtension: "json")!
        return try! Data(contentsOf: url)
    }
}
