//
//  RecipeRemoteRepository.swift
//  Reciplease
//
//  Created by Florian Fourcade on 20/08/2023.
//

import Foundation
import CoreData

struct RecipeLocalRepository: BaseRepository {
    
    typealias T = Recipe
    
    func create(record: Recipe) {
        let cdRecipe = CDRecipe(context: PersistentStorage.shared.context)
        cdRecipe.id = record.id
        cdRecipe.title = record.title
        cdRecipe.imageURL = record.imageURL ?? URL(string: "")!
        cdRecipe.yield = record.yield
        cdRecipe.totalTime = record.totalTime

        if record.ingredients.isEmpty == false {
            
            var ingredientsSet = Set<CDIngredient>()
            
            record.ingredients.forEach { ingredient in
                let cdIngredient = CDIngredient(context: PersistentStorage.shared.context)
                
                cdIngredient.title = ingredient.title
                cdIngredient.quantity = ingredient.quantity
                
                ingredientsSet.insert(cdIngredient)
            }

            cdRecipe.ingredients = ingredientsSet
        }

        PersistentStorage.shared.saveContext()
        
        print("Recipe added locally - ID: \(record.id)")
    }
    
    func getAll() -> [Recipe] {
        let records = PersistentStorage.shared.fetchManagedObject(managedObject: CDRecipe.self)
        guard let records, records.isEmpty == false else {
            print("No local recipes found.")
            return []
        }
        
        // Ajouter un journal de débogage pour suivre la récupération des recettes locales
        print("Retrieved \(records.count) local recipes.")
        
        return records.compactMap { $0.convertToRecipe() }
    }

    
    func get(byIdentifier id: String) -> Recipe? {
        guard let cdRecipe = getCdRecipe(byIdentifier: id) else { return nil }
        return cdRecipe.convertToRecipe()
    }
    
    func delete(byIdentifier id: String) -> Bool {
        guard let cdRecipe = getCdRecipe(byIdentifier: id) else { return false }

        PersistentStorage.shared.context.delete(cdRecipe)
        PersistentStorage.shared.saveContext()
        
        print("Recipe deleted locally - ID: \(id)")

        return true
    }
}

// MARK: - Convenience Methods

extension RecipeLocalRepository {
    
    private func getCdRecipe(byIdentifier id: String) -> CDRecipe? {
        let fetchRequest = NSFetchRequest<CDRecipe>(entityName: "CDRecipe")
        let fetchById = NSPredicate(format: "id==%@", id as CVarArg)
        fetchRequest.predicate = fetchById

        let result = try! PersistentStorage.shared.context.fetch(fetchRequest)
        guard result.count != 0 else {return nil}

        return result.first
    }
}
