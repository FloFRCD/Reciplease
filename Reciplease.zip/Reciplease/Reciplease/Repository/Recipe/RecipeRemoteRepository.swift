import Foundation
import CoreData
import Alamofire

// TODO: Le RecipeService doit gérer la pagination
// Le ViewController ne doit recevoir que des [Recipe]
// RecipeService: private 'let nextUrl: String?'

protocol AlamofireServiceProtocol {
    func request(_ convertible: URLConvertible, method: HTTPMethod, parameters: Parameters? , encoding: ParameterEncoding , headers: HTTPHeaders? , interceptor: RequestInterceptor?, completion : @escaping (Data?) -> Void)
}

class AlamofireRecipeService: AlamofireServiceProtocol {
    func request(_ convertible: URLConvertible, method: HTTPMethod, parameters: Parameters?, encoding: ParameterEncoding, headers: HTTPHeaders?, interceptor: RequestInterceptor?, completion: @escaping (Data?) -> Void) {
        AF.request(convertible , method: method, parameters: parameters, encoding: encoding, headers: headers, interceptor: interceptor).response  { (responseData) in
            completion(responseData.data)
        }
    }
}



//Class pour appel reseau avec Alamofire

class RecipeRemoteRepository {
    
    private var recipeNextUrl: String?
    
    private var session: URLSessionProtocol
    
    init(withSession session: URLSessionProtocol = URLSession.shared) {
        self.session = session
    }

    func getRecipes(ingredients: [String], completion: @escaping (Result<[Recipe], Error>) -> Void) {
        guard let ingredientsQuery = ingredients.joined(separator: ",").addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) else {
            completion(.failure(RecipleaseError.requestError))
            return
        }

        let recipeSearchRequest = Environment.baseUrl + "q=\(ingredientsQuery)" + Environment.key
                print("requestUrl: \(ingredientsQuery)")
        guard let url = URL(string: recipeSearchRequest) else {
            completion(.failure(RecipleaseError.urlError))
            return
        }
        
        let dataTask = session.dataTask(with: url) { (data, response, error) in
            guard let statusCode = (response as? HTTPURLResponse)?.statusCode else {
                return
            }
            
            switch statusCode {
            case 200:
                guard let data = data else {
                    completion(.failure(RecipleaseError.noData))
                    return
                }
                do {
                    let response = try JSONDecoder().decode(RecipeResponse.self, from: data)
                    // Initialiser les propriétés permettant de récupérer les prochaines recettes :
                    // Un booléen? Pour savoir s'il y a d'autres recettes?
                    // Un url? Nous donnant les prochaines recettes?
                    // from - to? En paramètre?
                    let recipes = response.hits.compactMap { $0.recipe }
                    completion(.success(recipes))
                } catch {
                    completion(.failure(RecipleaseError.parseError))
                }
            case 404:
                completion(.failure(RecipleaseError.urlError))
            default:
                completion(.failure(RecipleaseError.statusCode(statusCode)))
            }
        }
        
        dataTask.resume()
    }
    
    func nextRecipes() {
        // Vérifier si de nouvelles recettes sont disponibles (lire le booléen ?)
        // Récupérer le lien de l'appel précédent et ajouter les queryParameters 'from' & 'to'
    }
}

protocol IngredientDelegate: AnyObject {
    func ingredientsDidUpdate(_ ingredients: [String])
}

//pour UITest
protocol ImageRecipeServiceAlamofireProtocol {
    func request(_ urlImage : String, completion : @escaping (Data?) -> Void)
}

class ImageRecipeService: ImageRecipeServiceAlamofireProtocol {
    func request(_ urlImage: String, completion: @escaping (Data?) -> Void) {
        AF.request(urlImage).response { (response) in
            completion(response.data)
        }
    }
}

//Appel reseau API

class ImageRecipeServiceAlamofire {
    
    typealias ImageCallBack = (_ recipe: Data?, _ status:  Bool) -> Void
    
    init(requester: ImageRecipeServiceAlamofireProtocol) {
        self.requester = requester
    }
    
    var requester: ImageRecipeServiceAlamofireProtocol
    
    func getImage(urlImage: String, callBack: @escaping ImageCallBack) {
        requester.request(urlImage) { (response) in
            DispatchQueue.main.async {
                guard let data = response else{
                    callBack(nil, false)
                    return
                }
                callBack(data, true)
            }
        }
    }
}
