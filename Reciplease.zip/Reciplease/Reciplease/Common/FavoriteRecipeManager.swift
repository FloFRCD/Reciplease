////
////  FavoriteRecipeManager.swift
////  Reciplease
////
////  Created by Florian Fourcade on 07/08/2022.
////
//
import Foundation

protocol FavoriteRecipeProtocol {
    func loadFavoriteRecipe()
    func removeRecipe(at index : Int, completion : @escaping (Bool) -> Void)
    func addToFavorite(_ recipe : Recipe)

    func test(_ title: String) -> Bool
    var arrayFavoriteRecipe: [Recipe] {get set}
}


//class FavoriteRecipeManager : FavoriteRecipeProtocol {
//
//    //singleton
//    static var shared = FavoriteRecipeManager()
//
//    var storage: StorageManagerProtocol!
//    var arrayFavoriteRecipe: [Recipe]
//
//    private init() {
//        self.storage = StorageManager()
//        self.arrayFavoriteRecipe = []
//    }
//
//    //Ajouter une recette
//    func loadFavoriteRecipe() {
//        arrayFavoriteRecipe = storage.fetchRecipe()
//    }
//
//    //Suppression de recette
//    func removeRecipe(at index : Int, completion : @escaping (Bool) -> Void){
//        storage.deleteRecipe(arrayFavoriteRecipe[index]) { [weak self] statut in
//            if statut == true{
//                self?.arrayFavoriteRecipe.remove(at: index)
//            }
//            completion (statut)
//        }
//    }
//
//    func addToFavorite(_ recipe : Recipe){
//        storage.persist(recipe)
//    }
//
//    // Pour savoir si on a deja la recette
//    func test(_ title : String) -> Bool {
//        for i in 0 ..< arrayFavoriteRecipe.count{
//            if arrayFavoriteRecipe[i].title == title {
//                return true
//            }
//        }
//        return false
//    }
//}
