//
//  UIView+.swift
//  RecipleaseTests
//
//  Created by Florian Fourcade on 22/08/2022.
//

import Foundation
import UIKit

extension UIView {
    
    var isVisible: Bool {
        get { !self.isHidden }
        set { self.isHidden = !newValue }
    }
}
