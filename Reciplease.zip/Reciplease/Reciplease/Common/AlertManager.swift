import Foundation
import UIKit

struct AlertManager{

    enum AlertType{
        case EmptyList
        case EmptyIngredient
        
        var description : String{
            switch self{
            case .EmptyList:
                return "Votre liste est vide"
            case .EmptyIngredient:
                return ""
            }
        }
    }
    

    
    func alertVc(_ message: AlertType, _ controller : UIViewController){
        let alertVC = UIAlertController(title: "Zéro!", message: "\(message.description)", preferredStyle: .alert)
        alertVC.addAction(UIAlertAction(title: "OK", style: .cancel, handler: nil))
        controller.present(alertVC, animated: true, completion: nil)
        }
}
