//
//  RecipleaseError.swift
//  Reciplease
//
//  Created by Florian Fourcade on 03/09/2023.
//

import Foundation

enum RecipleaseError: Error, Equatable {
    // MARK: - Network
    case requestError
    case urlError
    case noData
    case parseError
    case statusCode(Int)
    
    static func ==(lhs: RecipleaseError, rhs: RecipleaseError) -> Bool {
        switch (lhs, rhs) {
        case (.requestError, .requestError),
            (.urlError, .urlError),
            (.noData, .noData),
            (.parseError, .parseError):
            return true
        case let (.statusCode(code1), .statusCode(code2)):
            return code1 == code2
        default:
            return false
        }
    }
}
