import Foundation

struct Environment {
    
    let search = SearchController()
    
    static let baseUrl = "https://api.edamam.com/search?"
    static let key = "&app_id=afdfe5b8&app_key=d83d62ebada0e8ed2275395ecb91f1e2&time=1"
    

}
